# Responsible Disclosure of Security Vulnerabilities

- ⚠️ **Do not open public issues on GitHub to report security vulnerabilities.**
- Contact us privately first, in a
  [responsible disclosure](https://en.wikipedia.org/wiki/Responsible_disclosure)
  manner.
- On IRC, send a private message to any voiced user on our Libera.Chat channel,
  `#thelounge`.
- By email, send us your report at <security@thelounge.chat>.
