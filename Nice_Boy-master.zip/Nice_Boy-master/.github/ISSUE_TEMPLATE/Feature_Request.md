---
name: Feature Request
about: Request a new feature
labels: "Type: Feature"
---

<!-- Have a question? Join #thelounge on Libera.Chat. -->
<!-- Make sure to check the existing issues prior to submitting your suggestion. -->

### Feature Description
