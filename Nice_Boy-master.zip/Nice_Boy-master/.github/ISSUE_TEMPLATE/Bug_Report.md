---
name: Bug Report
about: Create a bug report
labels: "Type: Bug"
---

<!-- Have a question? Join #thelounge on Libera.Chat -->

- _Node version:_
- _Browser version:_
- _Device, operating system:_
- _The Lounge version:_

---
