## Support

Welcome to The Lounge, it's great to have you here! If you have a question, or
need help, you have a few options:

- Check out [existing questions on Stack Overflow](https://stackoverflow.com/questions/tagged/thelounge)
  to see if yours has been answered before. If not, feel free to [ask for a new question](https://stackoverflow.com/questions/ask?tags=thelounge)
  (using `thelounge` tag so that other people can easily find it).
- Find us on the Libera.Chat channel `#thelounge`. You might not get an answer
  right away, but this channel is full of nice people who will be happy to
  help you.
