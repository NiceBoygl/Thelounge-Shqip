"use strict";

const home = require("path").join(__dirname, ".thelounge");
require("../../src/helper").setHome(home);
